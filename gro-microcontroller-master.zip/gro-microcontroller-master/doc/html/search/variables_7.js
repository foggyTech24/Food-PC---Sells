var searchData=
[
  ['not_5fconnected_5f',['not_connected_',['../class_communication.html#a566d648baea3543f997db397e7467a75',1,'Communication']]]
];
