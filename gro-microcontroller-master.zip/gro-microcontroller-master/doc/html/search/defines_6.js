var searchData=
[
  ['leap_5fyear',['LEAP_YEAR',['../support__time_8cpp.html#ac0623a9834738f5c6747faef9119c7b1',1,'support_time.cpp']]],
  ['lux_5fscale',['LUX_SCALE',['../sensor__tsl2561_8h.html#abe3540b1f05e5974dfa40491719b322a',1,'sensor_tsl2561.h']]]
];
