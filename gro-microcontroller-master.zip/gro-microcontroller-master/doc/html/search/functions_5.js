var searchData=
[
  ['flush',['flush',['../class_software_serial.html#a9a46db376a19fc958e011e38799b902c',1,'SoftwareSerial::flush()'],['../class_two_wire.html#a4d92ddf6ca349c815de1de15fca06b5e',1,'TwoWire::flush()']]]
];
