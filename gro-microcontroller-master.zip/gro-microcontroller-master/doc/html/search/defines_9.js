var searchData=
[
  ['ratio_5fscale',['RATIO_SCALE',['../sensor__tsl2561_8h.html#a2d36ccf8157f890c015eddd64276d77c',1,'sensor_tsl2561.h']]]
];
