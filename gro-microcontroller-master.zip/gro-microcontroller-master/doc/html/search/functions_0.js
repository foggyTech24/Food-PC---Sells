var searchData=
[
  ['actuatorrelay',['ActuatorRelay',['../class_actuator_relay.html#a0a19fabbd9a3ee500d906a55579ae4f3',1,'ActuatorRelay']]],
  ['adjusttime',['adjustTime',['../support__time_8cpp.html#acc6ec9a3678824ee0b252511300cf070',1,'support_time.cpp']]],
  ['available',['available',['../class_communication.html#a086f2246c7e3715c8de1bc96cfbce262',1,'Communication::available()'],['../class_software_serial.html#a4cbf77a4e90e15ca576972d7952659c5',1,'SoftwareSerial::available()'],['../class_two_wire.html#aee57bc52bee06508e231c5fc6bc35ada',1,'TwoWire::available()']]]
];
