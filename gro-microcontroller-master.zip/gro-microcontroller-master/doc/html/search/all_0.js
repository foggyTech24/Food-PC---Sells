var searchData=
[
  ['_5fdebug',['_DEBUG',['../support__software__serial_8cpp.html#a152fc5203b90b1cff03b7b78579b8f52',1,'support_software_serial.cpp']]],
  ['_5fdebug_5fpin1',['_DEBUG_PIN1',['../support__software__serial_8cpp.html#a43461cbce55a8b1f98dae56d963c941d',1,'support_software_serial.cpp']]],
  ['_5fdebug_5fpin2',['_DEBUG_PIN2',['../support__software__serial_8cpp.html#af51dd94e466b8a6a5fb199736b78e531',1,'support_software_serial.cpp']]],
  ['_5fss_5fmax_5frx_5fbuff',['_SS_MAX_RX_BUFF',['../support__software__serial_8h.html#af67c8adbca054838dd8a5b9043ffd64a',1,'support_software_serial.h']]]
];
