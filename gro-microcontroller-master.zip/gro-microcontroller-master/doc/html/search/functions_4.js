var searchData=
[
  ['end',['end',['../class_software_serial.html#a9034270f7de617b3cc7d3f38f3a8e0df',1,'SoftwareSerial']]],
  ['endtransmission',['endTransmission',['../class_two_wire.html#af80f9a7b85a3a81a035ca94c95bcdc1d',1,'TwoWire::endTransmission(void)'],['../class_two_wire.html#a289f5ef9bb0f79b31095fd72402ed54a',1,'TwoWire::endTransmission(uint8_t)']]]
];
