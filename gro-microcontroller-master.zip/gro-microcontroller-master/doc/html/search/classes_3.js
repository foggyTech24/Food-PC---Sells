var searchData=
[
  ['movingaveragefilter',['MovingAverageFilter',['../class_moving_average_filter.html',1,'']]]
];
