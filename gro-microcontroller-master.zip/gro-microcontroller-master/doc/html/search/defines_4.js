var searchData=
[
  ['gcc_5fversion',['GCC_VERSION',['../support__software__serial_8h.html#adbba0f726fc66d7100916c683b7568ae',1,'support_software_serial.h']]]
];
