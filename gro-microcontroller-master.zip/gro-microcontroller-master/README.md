# gro-microcontroller
Code running on bot's microcontroller (Arduino Mega 2560).
